mod error;
mod handle_esp_request;
mod models;
mod session;

use std::{
    collections::HashMap,
    net::IpAddr,
    sync::{Arc, Mutex},
    time::Duration,
};

use futures::{future, SinkExt, StreamExt, TryStreamExt};
use tokio::{net::TcpListener, sync::mpsc::channel};
use tokio_tungstenite::tungstenite::Message;

use self::error::WeatherError;
use self::models::{SessionState, WeatherDataEvent, WeatherValues, WsMessage};
use self::session::Session;

const ESP_INCOMING_PORT: u16 = 1337;
const WS_INCOMING_PORT: u16 = 8080;

#[tokio::main]
async fn main() {
    let devices = Arc::new(Mutex::new(HashMap::<String, SessionState>::new()));

    devices
        .lock()
        .unwrap()
        .insert("0a1c3bbf72".to_string(), Default::default());

    let esp_listener = TcpListener::bind(("0.0.0.0".parse::<IpAddr>().unwrap(), ESP_INCOMING_PORT))
        .await
        .unwrap();

    let websocket_listener =
        TcpListener::bind(("0.0.0.0".parse::<IpAddr>().unwrap(), WS_INCOMING_PORT))
            .await
            .unwrap();

    let (tx, mut rx) = channel::<WeatherDataEvent>(1);

    tokio::spawn(async move {
        loop {
            let (stream, addr) = match esp_listener.accept().await {
                Ok(n) => n,
                Err(e) => {
                    eprintln!("Failed to get client: {:?}", e);
                    continue;
                }
            };

            tokio::spawn(self::handle_esp_request::handle(stream, addr, tx.clone()));
        }
    });

    {
        let devices = devices.clone();

        tokio::spawn(async move {
            loop {
                while let Some(event) = rx.recv().await {
                    {
                        devices
                            .lock()
                            .unwrap()
                            .entry(event.unique_device_id.clone())
                            .or_insert_with(|| SessionState::default())
                            .values = WeatherValues::from(event.values);
                    }

                    let sessions = devices
                        .lock()
                        .unwrap()
                        .entry(event.unique_device_id.clone())
                        .or_insert_with(|| SessionState::default())
                        .connected_sessions
                        .clone();

                    for tx in sessions.values() {
                        println!("Sending event to session");
                        tx.try_send(event.values.into()).ok();
                    }
                }
            }
        });
    }

    loop {
        let (stream, addr) = match websocket_listener.accept().await {
            Ok(n) => n,
            Err(e) => {
                eprintln!("Failed to get client: {:?}", e);
                continue;
            }
        };

        println!("Got TCP connection in websocket listener");

        let devices = devices.clone();

        tokio::spawn(async move {
            let stream = match tokio_tungstenite::accept_async(stream).await {
                Ok(n) => n,
                Err(e) => {
                    eprintln!("[{}] Failed to accept websocket stream: {:?}", addr, e);
                    return;
                }
            };

            let mut stream = stream
                .and_then(|x| {
                    future::ok(serde_json::from_slice::<WsMessage>(
                        x.into_data().as_slice(),
                    ))
                })
                .map::<Result<_, WeatherError>, _>(|x| {
                    x.map_err(|e| e.into())
                        .and_then(|x| x.map_err(|e| e.into()))
                })
                .with::<WsMessage, _, _, _>(|x| {
                    future::ok::<_, WeatherError>({
                        let json = serde_json::to_string(&x).unwrap();

                        Message::Text(json)
                    })
                });

            let first_msg = match stream
                .next()
                .await
                .ok_or(WeatherError::ConnectionBroken)
                .and_then(|x| x)
            {
                Ok(n) => n,
                Err(e) => {
                    eprintln!(
                        "[{}] Failed to read first message from websocket stream: {:?}",
                        addr, e
                    );
                    return;
                }
            };

            let (unique_device_id, _password) = match first_msg {
                WsMessage::Identify {
                    unique_device_id,
                    password,
                } => (unique_device_id, password),
                _ => {
                    eprintln!("[{}] Unexpected message", addr);
                    return;
                }
            };

            println!("Got websocket connection for device `{}`", unique_device_id);

            let session_id = rand::random();

            let (session, mut rx, initial_values) =
                match devices.lock().unwrap().get_mut(&unique_device_id) {
                    Some(n) => {
                        let (tx, rx) = channel::<WeatherValues>(1);
                        let session = Session {
                            session_id,
                            unique_device_id,
                            state: devices.clone(),
                        };

                        n.connected_sessions.insert(session_id, tx);
                        (session, rx, n.values.clone())
                    }
                    None => {
                        eprintln!("[{}] Device `{}` not found", addr, unique_device_id);
                        return;
                    }
                };

            match stream
                .send(WsMessage::WeatherDataEvent(initial_values))
                .await
            {
                Ok(_) => {}
                Err(e) => {
                    eprintln!("[{}] Lost connection: {:?}", addr, e);
                    drop(session);
                    return;
                }
            }

            let mut interval = tokio::time::interval(Duration::from_secs(5));

            interval.tick().await; // Ticks immediately

            loop {
                let event = tokio::select! {
                    _ = interval.tick() => {
                        match stream.send(WsMessage::KeepAlive).await {
                            Ok(_) => {}
                            Err(e) => {
                                eprintln!("[{}] Lost connection: {:?}", addr, e);
                                drop(session);
                                return;
                            }
                        };

                        continue;
                    },
                    v = rx.recv() => v
                };

                let values = match event {
                    Some(n) => n,
                    None => {
                        eprintln!("[{}] RX closed", addr);
                        drop(session);
                        return;
                    }
                };

                match stream.send(WsMessage::WeatherDataEvent(values)).await {
                    Ok(_) => {}
                    Err(e) => {
                        eprintln!("[{}] Lost connection: {:?}", addr, e);
                        drop(session);
                        return;
                    }
                }
            }
        });
    }
}
