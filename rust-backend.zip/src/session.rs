use std::{
    collections::HashMap,
    sync::{Arc, Mutex},
};

use crate::models::SessionState;

pub struct Session {
    pub session_id: usize,
    pub unique_device_id: String,
    pub state: Arc<Mutex<HashMap<String, SessionState>>>,
}

impl Drop for Session {
    fn drop(&mut self) {
        match self.state.lock().unwrap().get_mut(&self.unique_device_id) {
            Some(n) => {
                n.connected_sessions.remove(&self.session_id);
            }
            None => return,
        }
    }
}
