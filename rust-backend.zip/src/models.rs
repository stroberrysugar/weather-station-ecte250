use std::collections::HashMap;

use serde::{Deserialize, Serialize};
use tokio::sync::mpsc::Sender;

#[derive(Deserialize, Serialize)]
#[serde(tag = "type", content = "data", rename_all = "snake_case")]
pub enum WsMessage {
    Identify {
        unique_device_id: String,
        password: String,
    },
    WeatherDataEvent(WeatherValues),
    KeepAlive,
}

#[derive(Clone, Default, Deserialize, Serialize)]
pub struct WeatherValues {
    pub humidity: f64,
    pub temperature: f64,
    pub uv_index: f64,
    pub pressure: f64,
    pub wind_speed: f64,
    pub wind_direction: f64,
}

pub struct WeatherDataEvent {
    pub unique_device_id: String,
    pub values: [f64; 6],
}

#[derive(Clone, Default)]
pub struct SessionState {
    pub connected_sessions: HashMap<usize, Sender<WeatherValues>>,
    pub values: WeatherValues,
}

impl From<[f64; 6]> for WeatherValues {
    fn from(value: [f64; 6]) -> Self {
        WeatherValues {
            humidity: value[0],
            temperature: value[1],
            uv_index: value[2],
            pressure: value[3],
            wind_speed: value[4],
            wind_direction: value[5],
        }
    }
}
