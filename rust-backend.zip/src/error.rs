#[derive(Debug)]
pub enum WeatherError {
    Serde(serde_json::Error),
    Tungstenite(tokio_tungstenite::tungstenite::Error),
    ConnectionBroken,
}

impl From<serde_json::Error> for WeatherError {
    fn from(value: serde_json::Error) -> Self {
        WeatherError::Serde(value)
    }
}

impl From<tokio_tungstenite::tungstenite::Error> for WeatherError {
    fn from(value: tokio_tungstenite::tungstenite::Error) -> Self {
        WeatherError::Tungstenite(value)
    }
}
