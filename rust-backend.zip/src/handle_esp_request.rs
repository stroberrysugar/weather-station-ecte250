use std::{net::SocketAddr, time::Duration};

use tokio::{io::AsyncReadExt, net::TcpStream, sync::mpsc::Sender, time::timeout};

use crate::WeatherDataEvent;

const WEBHOOK_URL: &str = "https://discord.com/api/webhooks/1296272760208621568/hD-oGOYJRoyUByzOaoRl0sdaTcF2qAGE03hWstEnW5domjwYV1oqN81f13dzc8dv4ySX";

pub async fn handle(mut stream: TcpStream, addr: SocketAddr, tx: Sender<WeatherDataEvent>) {
    let mut msg = String::new();

    match timeout(Duration::from_secs(5), stream.read_to_string(&mut msg)).await {
        Ok(n) => match n {
            Ok(_) => {}
            Err(e) => {
                eprintln!(
                    "[{}] Error while reading message from client: {:?}",
                    addr, e
                );
                return;
            }
        },
        Err(_) => {
            eprintln!("[{}] Timed out while reading message from client", addr);
            return;
        }
    };

    /*

    IN ESP32 code:

    client.printf("%s;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f\n",
      UNIQUE_DEVICE_ID, humidity, temperature, uvIndex, pressure, windSpeed, headingDegrees);

    0a1c3bbf72;55.10;23.60;0.00;1016.51;0.00;60.26

      */

    let components = msg.trim().split(';').collect::<Vec<_>>();

    if components.len() != 7 {
        eprintln!(
            "[{}] Expected 7 components. Found {}. Message got: {}",
            addr,
            components.len(),
            msg
        );

        return;
    }

    println!("Message: {}", msg);

    let unique_device_id = components[0];

    let values: [f64; 6] = components[1..]
        .iter()
        .map(|x| x.parse::<f64>().unwrap_or_else(|_| f64::NAN))
        .collect::<Vec<_>>()
        .try_into()
        .unwrap();

    // Send data to websocket

    tx.send(WeatherDataEvent {
        unique_device_id: unique_device_id.to_string(),
        values,
    })
    .await
    .ok();

    // Construct discord webhook

    let humidity = format!("{:.1}%", values[0]);
    let temperature = format!("{:.1} °C", values[1]);
    let uv_index = format!("{:.1}%", values[2]);
    let pressure = format!("{:.1} hPa", values[3]);
    let wind_speed = format!("{:.1} km/h", values[4]);
    let wind_direction = format!("{} ({:.0} °)", get_direction(values[5]), values[5]);

    let webhook_body = serde_json::json!({
      "content": null,
      "embeds": [
        {
          "title": "Weather station event",
          "color": 5814783,
          "fields": [
            {
              "name": "Temperature",
              "value": temperature,
              "inline": true
            },
            {
              "name": "Humidity",
              "value": humidity,
              "inline": true
            },
            {
              "name": "Pressure",
              "value": pressure,
              "inline": true
            },
            {
              "name": "UV index",
              "value": uv_index,
              "inline": true
            },
            {
              "name": "Wind speed",
              "value": wind_speed,
              "inline": true
            },
            {
              "name": "Wind direction",
              "value": wind_direction,
              "inline": true
            }
          ],
          "author": {
            "name": format!("Unique Device ID: {}", unique_device_id)
          },
          "footer": {
            "text": format!("IP address: {}", addr.ip())
          }
        }
      ],
      "attachments": []
    });

    reqwest::Client::new()
        .post(WEBHOOK_URL)
        .json(&webhook_body)
        .send()
        .await
        .ok();
}

fn get_direction(heading_degrees: f64) -> &'static str {
    match heading_degrees {
        d if d >= 337.5 || d < 22.5 => "N",
        d if d >= 22.5 && d < 67.5 => "NE",
        d if d >= 67.5 && d < 112.5 => "E",
        d if d >= 112.5 && d < 157.5 => "SE",
        d if d >= 157.5 && d < 202.5 => "S",
        d if d >= 202.5 && d < 247.5 => "SW",
        d if d >= 247.5 && d < 292.5 => "W",
        d if d >= 292.5 && d < 337.5 => "NW",
        _ => "Unknown", // Fallback case, though should never happen with the current logic
    }
}
